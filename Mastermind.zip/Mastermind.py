
import pygame as pg
import sys
import time

# initial variables
player = 'Coder'
winner = None
turn = 0
width = 600
height = 600
white = (255,255,255)
line_color = (0,0,0)
cnb = list() # cows and bulls list
code = [None, None, None, None]
guess = [None, None, None, None]
board = [[None]*4, [None]*4, [None]*4, [None]*4, [None]*4, [None]*4, [None]*4,[None]*4,[None]*4,[None]*4]
# pygame initialization
pg.init()
fps = 30
CLOCK = pg.time.Clock()
screen = pg.display.set_mode((width, height + 100), 0, 32)
# load images
pg.display.set_caption('Mastermind')
initiating_window = pg.image.load('mastermind-title.png')
yellow_img = pg.image.load('yellow-circle.png')
red_img = pg.image.load('red-circle.png')
blue_img = pg.image.load('blue-circle.png')
purple_img = pg.image.load('purple-circle.png')
orange_img = pg.image.load('orange-circle.png')
green_img = pg.image.load('green-circle.png')
cow_img = pg.image.load('cow.png')
bull_img = pg.image.load('bull.png')
x_img = pg.image.load('x-image.png')
# variables for the input box
input_box = pg.Rect(0, 650, 50, 50)
color_inactive = pg.Color('lightskyblue3')
color_active = pg.Color('dodgerblue2')
color = color_inactive
active = False
text = ''
done = False
font = pg.font.Font(None, 32)
# transform images
initiating_window = pg.transform.scale(initiating_window, (width, height + 100))
yellow_img = pg.transform.scale(yellow_img, (50,50))
red_img = pg.transform.scale(red_img, (50,50))
blue_img = pg.transform.scale(blue_img, (50,50))
purple_img = pg.transform.scale(purple_img, (50,50))
orange_img = pg.transform.scale(orange_img, (50,50))
green_img = pg.transform.scale(green_img, (50,50))
cow_img = pg.transform.scale(cow_img, (50,50))
bull_img = pg.transform.scale(bull_img, (50,50))
x_img = pg.transform.scale(x_img, (50,50))
initiating_window = pg.transform.scale(initiating_window, (100,100))

items = [yellow_img, red_img, blue_img, purple_img, orange_img, green_img, cow_img, bull_img]
colors_list = ['yellow', 'red', 'blue', 'purple', 'orange', 'green', 'cow', 'bull']

def color_to_number(color):
    
    """ Transforms a color to its index number and returns it """
    
    global items, colors_list
    
    color = color.lower()
    return items[colors_list.index(color)]
    


def coordinates(col, row):
    
    """ Returns the coordinates on the board with a given column-row pair """
    
    mm_width = width-300
    offset = 8
    posx = mm_width / 4 * (col - 1) + offset
    posy = height / 10 * (row - 1) + offset
    
    return [posx, posy]


def game_initiating_window():
    
    """ Prints the window which can be seen at the start of a game """
    
    mm_width = width-300
    screen.blit(initiating_window, (0,0))
    pg.display.update()
    # freeze screen for 1 second
    time.sleep(1)
    screen.fill(white)
    # draw the board lines
    for i in range(5):
        pg.draw.line(screen, line_color, (mm_width / 4 * i, 0), (mm_width / 4 * i , height), 7)    
    for i in range(11):
       pg.draw.line(screen, line_color, (0, height / 10 * i), (width, height / 10 * i), 7)
    
    status()
       


def status():
    
    """ Displays the status of the game: whose turn it is or who won """
    
    global code, winner
    
    if code == [None, None, None, None]:
        message = "Type code: (yellow, red, orange, purple)"
        
    if code != [None, None, None, None]:
        message = "Type guess: (yellow, red, orange, purple)"
        
    if winner is not None:
        message = winner.upper() + " won !"
    
    # if the Breaker can't the code in 9 turns, they lose
    elif turn > 9:
        winner = 'Coder'
        print(code)
        message = winner.upper() + " won !"

    # print the message in the text block
    font = pg.font.Font(None, 30)
    text = font.render(message, 1 , (255,255,255))
    screen.fill((0,0,0), (0, 600, 700, 100))
    text_rect = text.get_rect(center = (width / 2, 675-50))
    screen.blit(text, text_rect)
    pg.display.update()
    
    
def draw(item, col, row):
    
    """ Draws the ball with the right color in the given column and row """
    
    pos = coordinates(col, row)
    to_draw = color_to_number(item)
    screen.blit(to_draw, pos)
    
def coder(code):
    
    """ Transforms the character code written by the Coder into a list of individual colors and returns it"""
    
    res = []
    word = str()
    for i in code:
        if i == ' ' or i == '(' or i == ')':
            continue
        if i == ',':
            res.append(word)
            word = str()
        else:
            word = word + i
    res.append(word)
    
    return res

def guesser():
    
    """ Checks how close the guess is to the code and returns the list of cows and bulls """
    
    global code, guess, winner, turn
    
    cowsnbulls = [0,0]
    
    if code == guess:
        winner = 'Breaker'
    
    # main logic for the game, by iterating through the guess and code and checking each color
    for i in range(4):
        # if the guess-color is the same as the code-color, a bull is added to the list
        if guess[i] == code[i]:
            cowsnbulls[1] = cowsnbulls[1] + 1
        # no bulls and cows are added if the guess-color is not in the code
        elif guess[i] not in code:
            continue
        # a cow is added if the amount of equal colors is the same in the guess and in the code
        elif guess.count(guess[i]) == code.count(guess[i]):
            cowsnbulls[0] = cowsnbulls[0] + 1
        # no cow is added if the amount of equal guess-colors is bigger than the amount in the code
        elif guess.count(guess[i]) > code.count(guess[i]) and guess[i] in guess[0:i]:
            continue
        # a cow is added in the rest of the cases, which are when the amount of equal colors in the code 
        # are larger than the in the guess
        else:
            cowsnbulls[0] = cowsnbulls[0] + 1
    
    # draw the guesses on the board
    for i in range(4):
        draw(guess[i], i+1 , 10-turn)
        
    # draw the cows and bulls on the board
    for i in range(sum(cowsnbulls)):
        if cowsnbulls[1] > 0:
            draw('bull', i+5, 10-turn)
            cowsnbulls[1] = cowsnbulls[1] - 1
        elif cowsnbulls[0] > 0:
            draw('cow', i+5, 10-turn)
            cowsnbulls[0] = cowsnbulls[0] - 1
                    
    return cowsnbulls
        

def reset():
    
    """ Resets the board and starts the game from the beginning """

    global board, winner, player, code, guess, turn
    time.sleep(3)
    player = 'Coder'
    game_initiating_window()
    winner = None
    turn = 0
    board = board = [[None]*4, [None]*4, [None]*4, [None]*4, [None]*4, [None]*4, [None]*4,[None]*4,[None]*4,[None]*4]
    code = [None, None, None, None]
    guess = [None, None, None, None]          
            
game_initiating_window()


# main engine of the game, works with the inputs of the keyboard of the users and translates them into actions
# on the board
while(True):
    for event in pg.event.get():
        # if the quit-button of the window is pressed
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()
        # clicking with the mouse
        if event.type == pg.MOUSEBUTTONDOWN:
                # if the user clicked on the input_box rect
                if input_box.collidepoint(event.pos):
                    # toggle the active variable, which determines if the user can type in the text box
                    active = not active
                else:
                    active = False
                # Change the current color of the input box.
                color = color_active if active else color_inactive
                
        # typing in the text box
        if event.type == pg.KEYDOWN:
            if active and player == 'Coder':
                # pressing enter locks in the code 
                if event.key == pg.K_RETURN:
                    code = coder(text)
                    text = ''
                    player = 'Breaker'
                    status()
                # deleting text with the backspace
                elif event.key == pg.K_BACKSPACE:
                    text = text[:-1]
                else:
                    text += event.unicode
            elif active and player == 'Breaker':
                # pressing enter makes a guess
                if event.key == pg.K_RETURN:
                    guess = coder(text)
                    cnb = guesser()
                    text = ''
                    turn = turn + 1
                    status()
                # deleting text with the backspace
                elif event.key == pg.K_BACKSPACE:
                    text = text[:-1]
                else:
                    text += event.unicode
                        
                    if winner != None:
                        reset()
            
                    
    # resets the screen to print the results of the event                   
    screen.fill((0,0,0), (0, 650, 600, 50))
    txt_surface = font.render(text, True, color)
    # resize the box if the text is too long
    width = max(600, txt_surface.get_width()+10)
    input_box.w = width
    # print the text
    screen.blit(txt_surface, (input_box.x+5, input_box.y+5))
    # print the input_box rect
    pg.draw.rect(screen, color, input_box, 2)
    pg.display.update()
    CLOCK.tick(fps)


    
    
    
    
    