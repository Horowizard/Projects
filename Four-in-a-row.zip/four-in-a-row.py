import pygame as pg
import sys
import time
from pygame.locals import *

# initial variables
turn = 'Yellow' # whose turn it is
winner = None
draw = None
# board dimensions
width = 700
height = 600
# the board as a matrix
board = [[None]*6, [None]*6, [None]*6, [None]*6, [None]*6, [None]*6, [None]*6]
# color definitions
white = (255,255,255)
line_color = (0,0,255)
# a variable to keep track of how full each column is
filling = [0,0,0,0,0,0,0]

# pygame intialization
pg.init()
fps = 30
CLOCK = pg.time.Clock()
screen = pg.display.set_mode((width, height + 100), 0, 32) # add extra space for text
pg.display.set_caption('Vier op een rij')
# load images
initiating_window = pg.image.load('four-in-a-row-title.png')
yellow_img = pg.image.load('yellow-circle.png')
red_img = pg.image.load('red-circle.png')
x_img = pg.image.load('x-image.png')
# transform images
initiating_window = pg.transform.scale(initiating_window, (width, height + 100))
yellow_img = pg.transform.scale(yellow_img, (80,80))
red_img = pg.transform.scale(red_img, (80,80))
x_img = pg.transform.scale(x_img, (50,50))


def game_initiating_window():
    
    """ Shows the window that can be seen when starting a game """
    
    screen.blit(initiating_window, (0,0))
    pg.display.update()
    # freeze screen for one second 
    time.sleep(1)
    screen.fill(white) 
    # plot lines on the board
    
    for i in range(8):
        pg.draw.line(screen, line_color, (width / 7 * i, 0), (width / 7 * i , height), 7)

    for i in range(7):
       pg.draw.line(screen, line_color, (0, height / 6 * i), (width, height / 6 * i), 7)

    # print the status of the game: whose turn it is, who won or if it's a draw
    status()
    
    
    
def status():
    
    """ Displays the status on the board: whose turn it is, who won or if it's a draw """
    
    global draw
    
    if winner is None:
        message = turn.upper() + " 's Turn"
    else:
        message = winner.upper() + " won !"   
    if draw:
        message = "Game Draw !"
     
    # get text in the right format
    font = pg.font.Font(None, 30)
    text = font.render(message, 1 , (255,255,255))
    # empty the text block
    screen.fill((0,0,0), (0, 600, 700, 100))
    # print the text block
    text_rect = text.get_rect(center = (width / 2, 650))
    screen.blit(text, text_rect)
    pg.display.update()
    
def drawturn(col):
    
    """ Draw the red and yellow balls on the board """
    
    global board, turn, filling, winner, draw
    
    offset = 10   
    posx = width / 7 * (col-1) + offset    
    posy = height / 6 * (5-filling[col-1]) + offset 
    row = filling[col-1] + 1
    
    # if a column is filled, no new balls can be printed, so a warning is printed
    if row > 6:
        print('Out of bounds')
     
    elif(turn == 'Yellow'):
        # pasting x_img over the screen at a coordinate position of (pos_y, posx) defined in the code above
        board[col-1][row-1] = turn
        screen.blit(yellow_img, (posx, posy))
        # change turn
        turn = 'Red'
        
    else:
        board[col-1][row-1] = turn
        screen.blit(red_img, (posx, posy))
        # change turn
        turn = 'Yellow'
    
    # update the filling of the board
    filling[col-1] = filling[col-1] + 1
    check_win()
    status()
    pg.display.update()
    
    
def user_click():
    
    """ Processes a click on the screen to a position on the board, and prints the appropriate color there """
    
    # get coordinates of mouse click
    x, y = pg.mouse.get_pos()
    # get column of mouse click, row is not needed because the ball will always be printed on the lowest 
    # possible row. If the user click is not on the board, the loop will return None
    for i in range(7):
        if x < width / 7 * (i+1):
            col = i + 1
            break
        else:
            col = None
       
    # after getting the row and col, we need to draw the images at the desired positions
    if(col and board[col-1] is not None):
        global turn
        drawturn(col)
        
def check_win():
    
    """ Checks if a player has four in a row """
    
    global winner, draw
    
    #Check draw
    filled_board = []
    for sublist in board:
        for item in sublist:
            filled_board.append(item)
            
    # if the board is filled entirely, it's a draw        
    if None not in filled_board:
        draw = True
        status()
        return
    
    # checking for wins is done by iterating through the board and checking if there are four in a row
    
    #Vertical wins
    for i in range(7):
        counts = 1
        for j in range(5):
            if board[i][j] == board[i][j+1] and board[i][j] != None: 
                counts = counts + 1
                if counts >= 4:
                    winner = board[i][j]
                    return
            else:
                counts = 1
                
    
    #Horizontal wins:
    for i in range(6):
        counts = 1
        for j in range(6):
            if board[j][i] == board[j+1][i] and board[j][i] != None:
                counts = counts + 1
                if counts >= 4: 
                    winner = board[j][i]
                    return
            else:
                counts = 1   
                
    #Left diagonal wins:
    for k in range(3):
        for i in range(4): 
            counts = 1
            for j in range(3):
                if board[j+i][j+k] == board[j+i+1][j+k+1] and board[j+i][j+k] != None:
                    counts = counts + 1
                    if counts >= 4:
                        winner = board[j+i][j+k]
                        return
                else:
                    counts = 1
                    
   
    #Right diagonal wins:
    for k in range(3):
        for i in range(4): 
            counts = 1
            for j in range(3):
                if board[6-j-i][j+k] == board[6-j-i-1][j+k+1] and board[6-j-i][j+k] != None:
                    counts = counts + 1
                    if counts >= 4:
                        winner = board[6-j-i][j+k]
                        return
                else:
                    counts = 1     
                    

def reset_game():
    
    """ Resets all variables """
    
    global board, winner, turn, draw, filling
    
    time.sleep(3)
    turn = 'Yellow'
    draw = False
    game_initiating_window()
    winner = None
    status()
    filling = [0,0,0,0,0,0,0]
    board = [[None]*6, [None]*6, [None]*6, [None]*6, [None]*6, [None]*6, [None]*6]
    
game_initiating_window()
    
while(True):
    for event in pg.event.get():
        if event.type == QUIT:
            pg.quit()
            sys.exit()
        elif event.type == MOUSEBUTTONDOWN:
            user_click()
            if(winner or draw):
                reset_game()
    pg.display.update()
    CLOCK.tick(fps)
         
    
